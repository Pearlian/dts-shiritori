Kelompok 1:
Pearlian Fitra Aufa
Parlaungan Sinamora
Pebri Prasetyo
Overyadi Dani Rahu
Oscar Dewata

Source Code: main.py
Executable (Compiled Code): shiritori\main.exe
Git Repository: https://github.com/Pearlian/prvt-dts-shiritori.git